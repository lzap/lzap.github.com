package SortingAnimations;

/*
 * Copyright (c) 2002 Lukas Zapletal [lzap@bach.cz]
 * Distributed under GNU license.
 */

class ShellSortAlgorithm extends SortAlgorithm {
    void sort(int a[]) throws Exception {
	int i, j, q, s;

	for(j = 1; j < a.length; j = 3*j+1);
        
        do {
            j = j/3;

            for(i = j; i < a.length; i++) {
                q = a[i];
                s = i;

                while((s >= j) && (q < a[s-j]))
                {
                    pause(s, s-j);
                    a[s] = a[s-j];
                    s = s-j;
                };

                a[s] = q;
            };
        } while(j != 0);
    }
}
