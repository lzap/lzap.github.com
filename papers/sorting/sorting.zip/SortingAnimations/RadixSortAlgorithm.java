package SortingAnimations;

/*
 * Copyright (c) 2002 Lukas Zapletal [lzap@bach.cz]
 * Distributed under GNU license.
 */

public class RadixSortAlgorithm extends SortAlgorithm {

    private void RadixSort(int a[], int l, int r, int bit) throws Exception {
        if (bit < 0 || l >= r)
            return;

        int la = l;
        int ra = r;

	while(la != ra) 
	{
            while (bitAt(a[la],bit) == 0 && la < ra) {
                la++;
                pause(la, ra);
            }
            while (bitAt(a[ra],bit) != 0 && ra > la) {
                ra--;
                pause(la, ra);
            }
            swap(a,la,ra);
	}
	if (bitAt(a[r],bit) == 0) ra++;

	RadixSort(a,l,ra-1,bit-1);
	RadixSort(a,ra,r,bit-1);
    }
    
    int bitAt(int n, int p) {
        return ((n >> p) & 0x0001);
    }

    public void sort(int a[]) throws Exception
    {
        RadixSort(a, 0, a.length - 1, 4*8-1);
    }
}
