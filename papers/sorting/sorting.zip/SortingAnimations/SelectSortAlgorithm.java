package SortingAnimations;

/*
 * Copyright (c) 2002 Lukas Zapletal [lzap@bach.cz]
 * Distributed under GNU license.
 */

public class SelectSortAlgorithm extends SortAlgorithm {
  
    public void sort(int a[]) throws Exception {
        int i, j, t, min;

        for (i = 0; i < a.length; i++) {
            min = i;

            // search for the maximum
            for (j = i+1; j < a.length; j++) {
                pause(j, i); // draw the lines
                if(a[j] < a[min]) {
                    min = j;
                }
            };
            swap(a, min, i);
        };
    }
}
