package SortingAnimations;

/*
 * Copyright (c) 2002 Lukas Zapletal [lzap@bach.cz]
 * Distributed under GNU license.
 */

public class InsertSortAlgorithm extends SortAlgorithm {
    public void sort(int a[]) throws Exception
    {
	int p, s, i; 
	
	for(i = 0; i < a.length; i++) {
            p = a[i]; // actual element
            s = i; // border

            // and put to right position
            while((s > 0) && (p < a[s-1])){
                a[s] = a[s-1];
                s--;
                pause(s, i); // draw the lines
            }

            a[s]=p;
	};
    }
}
