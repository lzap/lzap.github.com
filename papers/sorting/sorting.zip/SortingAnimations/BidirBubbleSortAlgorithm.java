package SortingAnimations;

/*
 * Copyright (c) 2002 Lukas Zapletal [lzap@bach.cz]
 * Distributed under GNU license.
 */

class BidirBubbleSortAlgorithm extends SortAlgorithm {
    void sort(int a[]) throws Exception {
	int k = 0, l = 0;
	int p = a.length - 1;

	while (l < p)
	{
            int i, j;

            for(i = l; i < a.length - 1; i++) {
                pause(l,p);
                if(a[i] > a[i+1]) {
                    swap(a, i, i+1);
                    k = i;
                };  //if
            };  //for

            p = k;

            for(j = p; j > l; j--) {
                pause(l,p);
                if(a[j] < a[j-1]) {
                    swap(a, j, j-1);
                    k = j;
                };  //if
            };  //for

            l = k;
	};  //while
    }
}
