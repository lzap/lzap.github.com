package SortingAnimations;

/*
 * Copyright (c) 2002 Lukas Zapletal [lzap@bach.cz]
 * Distributed under GNU license.
 */

public class BInsertSortAlgorithm extends SortAlgorithm {
    public void sort(int a[]) throws Exception
    {
	for (int i = 0; i < a.length; i++)
	{
            int q = a[i];
            int l = 0;
            int p = i;

            while(l < p) {
                int s = (l+p)/2;
                if (q >= a[s])
                    l = s + 1;
                else 
                    p = s;
                pause(p, i); // draw the lines
            };
            // shift the array
            for(int j = i; j > p; j--)
                a[j] = a[j-1];
            a[p] = q;
	};     
    }
}
