package SortingAnimations;

/*
 * Copyright (c) 2002 Lukas Zapletal [lzap@bach.cz]
 * Distributed under GNU license.
 */

class BubbleSortAlgorithm extends SortAlgorithm {
    void sort(int a[]) throws Exception {
	for (int i = a.length; i >= 0; i--) {
	    for (int j = 0; j < i; j++) {
		pause(i,j);
		if (a[j] > a[j+1])
                    swap(a, j, j+1);
	    }
	}
    }
}
