package cz.upol.inf01.zapletal.geom2;

import javax.vecmath.Vector2f;
import java.awt.geom.Point2D;
import java.util.Collection;
import java.util.Vector;

/**
 * Abstraktni trida krivky zadane parametricky -- ParametricCurve.
 *
 * Kazda krivka, ktera chce byt vykreslena tridou Desktop musi
 * byt implementovat toto rozhrani.
 *
 * @author Luk� Zapletal
 */
public abstract class ParametricCurve implements ParametricFunction {
    
    /** Parameter start value (e.g. -PI) */
    public abstract float getParameterStart();
    
    /** Parameter end value */
    public abstract float getParameterEnd();
    
    /** Upper or lower bound for line`s parameters */
    protected static final float PARAMETER_INFINITY = 100f;
    
    /** Computation accurancies */
    protected static final float ACCURANCY_DERIVATION = 0.01f;
    protected static final float ACCURANCY_INFLEX = 0.001f;
    protected static final float STEP_LDEPENDENCY = ACCURANCY_DERIVATION;
    
    /** Curve`s length */
    protected static final float ACCURANCY_LENGTH = 0.001f;
    protected float length = 0f;
    
    public Vector2f getDerivation1(float t) {
        return new Vector2f(
        getValue(t + ACCURANCY_DERIVATION).x - getValue(t).x,
        getValue(t + ACCURANCY_DERIVATION).y - getValue(t).y);
    }
    
    public Vector2f getDerivation2(float t) {
        return new Vector2f(
        getDerivation1(t + ACCURANCY_DERIVATION).x - getDerivation1(t).x,
        getDerivation1(t + ACCURANCY_DERIVATION).y - getDerivation1(t).y);
    }
    
    public ParametricCurve getDerivation1Vector(float t) {
        return new LineCurve(getDerivation1(t), getValue(t));
    }
    
    public ParametricCurve getDerivation2Vector(float t) {
        return new LineCurve(getDerivation2(t), getValue(t));
    }
    
    public ParametricCurve getNormalVector(float t) {
        return new LineCurve(new Vector2f(getDerivation1(t).y, - getDerivation1(t).x), getValue(t));
    }
    
    public float getCurvature(float t) {
        Vector2f d1 = getDerivation1(t);
        Vector2f d2 = getDerivation2(t);
        return (float) Math.abs(Math.sqrt(Math.pow(Math.abs(d1.dot(d2)), 2) / Math.pow(Math.abs(d1.dot(d1)), 3)));
    }
    
    public ParametricCurve getOsculationCircle(float t) {
        try {
            
            Vector2f d1 = getDerivation1(t);
            Vector2f d2 = getDerivation2(t);
            Point2D v = getValue(t);
            
            float num = d1.x * d1.x + d1.y * d1.y;
            float denom = d1.x * d2.y - d2.x * d1.y;
            
            double r = Math.pow(num, 3f / 2f) / Math.abs(denom);
            double m = v.getX() - d1.y * (num / denom);
            double n = v.getY() + d1.x * (num / denom);
            
            return new CircleCurve((float) r, new Point2D.Float((float) m, (float) n));
            
        } catch (Exception e) {
            return new CircleCurve(0f, new Point2D.Float(0f, 0f));
        }
    }
    
    private Collection inflexPoints = null;
    
    public static boolean linearDependent(Vector2f va, Vector2f vb) {
        Vector2f van = (Vector2f) va.clone();
        Vector2f vbn = (Vector2f) vb.clone();
        float koef = vb.x / va.x;
        van.x = va.x * koef;
        van.y = va.y * koef;
        // vectors equals?
        if (Math.abs(van.x - vbn.x) < ACCURANCY_INFLEX && Math.abs(van.y - vbn.y) < ACCURANCY_INFLEX) {
            return true;
        }
        // second vector null?
        vbn.add(van);
        if (vbn.x == 0 && vbn.y == 0) {
            return true;
        }
        return false;
    }
    
    public Collection getInflexPoints() {
        // already created?
        if (inflexPoints == null) {
            inflexPoints = new Vector(); // vetor is a linked list of objects
            for (float t = getParameterStart(); t < getParameterEnd(); t += STEP_LDEPENDENCY) {
                float k = getDerivation2(t).length();
                if (Math.abs(k) < ACCURANCY_INFLEX) {
                    inflexPoints.add(new Float(t));
                }
            }
        }
        return inflexPoints;
    }
    
    public float getLength() {
        // calculate the length
        if (length == 0f) {
            float max = getParameterEnd();
            float t = getParameterStart();
            Point2D.Float v1 = getValue(t);
            Point2D.Float v2 = getValue(t);
            for (t += ACCURANCY_LENGTH; t < max; t += ACCURANCY_LENGTH) {
                v1 = (Point2D.Float) v2.clone();
                v2 = getValue(t);
                length += Math.sqrt(Math.pow(v2.x - v1.x, 2) + Math.pow(v2.y - v1.y, 2));
            }
        }
        return length;
    }
}

