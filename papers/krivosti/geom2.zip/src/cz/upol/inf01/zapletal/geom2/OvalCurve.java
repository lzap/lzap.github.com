package cz.upol.inf01.zapletal.geom2;

import java.awt.geom.Point2D;

/**
 * Oval curve (ellipse).
 * Author: Luk� Zapletal [lzap@root.cz]
 * Date: 1.5.2003
 */
public class OvalCurve extends ParametricCurve {

    /** Position of centre */
    protected Point2D.Float c;
    /** Radius */
    protected float a;
    protected float b;

    public OvalCurve(float a, float b, Point2D.Float c) {
        this.c = c;
        this.a = a;
        this.b = b;
    }

    public OvalCurve(float a, float b) {
        this(a, b, new Point2D.Float(0, 0));
    }

    public OvalCurve() {
        this(100, 160);
    }

    /**
     * Implementation for this object.
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve
     */
    public Point2D.Float getValue(float t) {
        return new Point2D.Float(
            c.x + a * (float) Math.cos(t),
            c.y + b * (float) Math.sin(t));
    }

    /**
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve#getParameterEnd()
     */
    public float getParameterEnd() {
        return 2 * (float) Math.PI;
    }

    /**
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve#getParameterStart()
     */
    public float getParameterStart() {
        return 0;
    }
}
