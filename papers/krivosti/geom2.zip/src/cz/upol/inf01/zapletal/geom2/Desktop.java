package cz.upol.inf01.zapletal.geom2;

import java.awt.*;
import java.awt.geom.*;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JPanel;
import javax.swing.RepaintManager;

/**
 * Desktop trida se stara o kompletni zobrazovani
 * 
 * @author Luk� Zapletal
 */
public class Desktop extends JPanel {

    /** Delka os */
    private static final float axisLength = 1000f;

    /** Presnost kresleni (krok) */
    private static final float step = 0.1f;

    /** Kreslena krivka */
    private ParametricCurve pc;

    /** Ma se kreslit parametr? */
    private boolean drawParameter = false;
    private float parameter = 0f;

    public Desktop(ParametricCurve p) {
        setDoubleBuffered(true);
        setParametricCurve(p);
    }

    public void drawParameter(float t) {
        parameter = t;
        drawParameter = true;
        repaint();
    }

    /**
     * Make a mark in the given point (circle).
     * @param g2 Graphics to use
     * @param v The point to mark
     * @param c The color
     */
    private void mark(Graphics2D g2, Point2D.Float v, Color c) {
        Ellipse2D point = new Ellipse2D.Float(
                v.x - 5.0f,
                - v.y - 5.0f,
                10.0f,
                10.0f);
        g2.setColor(c);
        g2.setStroke(new BasicStroke(1.0f));
        g2.fill(point);
    }

    /** Hlavni kreslici rutina */
    public void paint(Graphics g) {
        Dimension dim = this.getSize();
        Graphics2D g2 = createGraphics2D(dim.width, dim.height, g);

        g2.clearRect(0, 0, dim.width, dim.height);

        // transformuj pocatek soustavy souradnic do stredu objektu
        g2.translate(((float) dim.width) / 2, ((float) dim.height) / 2);

        // kresli osy
        GeneralPath p = new GeneralPath(GeneralPath.WIND_NON_ZERO);
        p.moveTo(-axisLength, 0f);
        p.lineTo(axisLength, 0f);
        p.moveTo(0f, -axisLength);
        p.lineTo(0f, axisLength);
        p.closePath();
        g2.setStroke(new BasicStroke(1.0f));
        g2.setColor(Color.lightGray);
        g2.draw(p);

        // kresli (zvyrazni) parametr na krivce, tecnu atd,
        if (drawParameter) {

            // vypsani prvni krivosti
            float k1 = pc.getDerivation2(parameter).length();
            g2.setColor(Color.darkGray);
            g2.drawString("1. k�ivost: " + new Float(k1).toString(), (-dim.width / 2) + 5, (-dim.height / 2) + 20);
            k1 = pc.getLength();
            g2.drawString("d�lka k�ivky: " + new Float(k1).toString(), (-dim.width / 2) + 5, (-dim.height / 2) + 50);

            // nyni tecny vektor
            //System.out.println(pc.getDerivation1(parameter));
            g2.setColor(Color.red);
            drawCurve(g2, pc.getDerivation1Vector(parameter));

            // normalovy vektor
            //System.out.println(pc.getDerivation2(parameter));
            g2.setColor(Color.green);
            drawCurve(g2, pc.getNormalVector(parameter));

            // inflexni body
            Iterator i = pc.getInflexPoints().iterator();
            while (i.hasNext()) {
                mark(g2, pc.getValue(((Float)i.next()).floatValue()), Color.CYAN);
            }

            // oskulacni kruznice
            g2.setColor(Color.orange);
            drawCurve(g2, pc.getOsculationCircle(parameter));

            // uplne nakonec zvyrazneni parametru
            mark(g2, pc.getValue(parameter), Color.BLUE);
        }

        // kresli zadanou krivku
        g.setColor(Color.BLACK);
        drawCurve(g2, pc);

        g2.dispose();
    }

    private void drawCurve(Graphics2D g, ParametricCurve pc) {
        Point2D.Float v;
        float t;

        GeneralPath p = new GeneralPath(GeneralPath.WIND_NON_ZERO);
        float start = pc.getParameterStart();
        float end = pc.getParameterEnd();
        v = pc.getValue(start);
        p.moveTo(v.x, - v.y);
        for (t = start; t <= end; t += step) {
            v = pc.getValue(t);
            p.lineTo(v.x, - v.y);
        }
        // finish the line
        if (t != end) {
            v = pc.getValue(end);
            p.lineTo(v.x, - v.y);
        }
        p.lineTo(v.x, - v.y);
        g.setStroke(new BasicStroke(1.5f));
        g.draw(p);
    }

    public Graphics2D createGraphics2D(int width, int height, Graphics g) {

        Graphics2D g2 = (Graphics2D) g;

        g2.setBackground(getBackground());
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        return g2;
    }

    /**
     * It's possible to turn off double-buffering for just the repaint 
     * calls invoked directly on the non double buffered component.  
     * This can be done by overriding paintImmediately() (which is called 
     * as a result of repaint) and getting the current RepaintManager and 
     * turning off double buffering in the RepaintManager before calling 
     * super.paintImmediately(g).
     */
    public void paintImmediately(int x,int y,int w, int h) {
        RepaintManager repaintManager = null;
        boolean save = true;
        if (!isDoubleBuffered()) {
            repaintManager = RepaintManager.currentManager(this);
            save = repaintManager.isDoubleBufferingEnabled();
            repaintManager.setDoubleBufferingEnabled(false);
        }
        super.paintImmediately(x, y, w, h);

        if (repaintManager != null) {
            repaintManager.setDoubleBufferingEnabled(save);
        }
    }

    public void setParametricCurve(ParametricCurve pc) {
        this.pc = pc;
    }
}
