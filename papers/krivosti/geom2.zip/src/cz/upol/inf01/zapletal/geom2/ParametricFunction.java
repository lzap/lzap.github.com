package cz.upol.inf01.zapletal.geom2;

import java.awt.geom.Point2D;

/**
 * Zakladni parametricke vyjadreni
 * @author Lukas Zapletal
 */

public interface ParametricFunction {

	/**
	 * Parametricka rovnice.
	 * @param t parametr
	 * @return vypoctenou hodnotu pro danou krivku
	 */	
	Point2D.Float getValue(float t);
    
}
