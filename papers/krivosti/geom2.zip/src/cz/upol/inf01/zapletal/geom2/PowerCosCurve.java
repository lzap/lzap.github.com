package cz.upol.inf01.zapletal.geom2;

import java.awt.geom.Point2D;

/**
 * Author: Luk� Zapletal [lzap@root.cz]
 * Date: 1.5.2003
 */
public class PowerCosCurve extends ParametricCurve {

    public Point2D.Float getValue(float t) {
        return new Point2D.Float(
                (float) Math.pow(t, 2) * t,
                150 * (float) Math.cos(t));
    }

    /**
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve#getParameterEnd()
     */
    public float getParameterEnd() {
        return 2 * (float) Math.PI;
    }

    /**
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve#getParameterStart()
     */
    public float getParameterStart() {
        return 0;
    }
}
