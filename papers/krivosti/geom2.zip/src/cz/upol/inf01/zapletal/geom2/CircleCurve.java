package cz.upol.inf01.zapletal.geom2;

import java.awt.geom.Point2D;

/**
 * Implementation for circle curve.
 * Circle is special case of oval where a = b.
 * 
 * @author Luk� Zapletal
 */
public class CircleCurve extends OvalCurve {
	
	public CircleCurve(float r, Point2D.Float c) {
		this.c = c;
		this.b = this.a = r;
	}

	public CircleCurve(float r) {
		this(r, new Point2D.Float(0, 0));
	}

}
