package cz.upol.inf01.zapletal.geom2;

import org.gjt.sp.jedit.textarea.JEditTextArea;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * @author Luk� Zapletal
 *
 */
public class MainFrame extends JFrame {
    private static final float approx = 100f;
    private JSlider slider = new JSlider(JSlider.HORIZONTAL);
    private ParametricCurve paraCurve = new CircleCurve(150f);
    private Desktop desktop;
    private JSplitPane mainPane;
    //private JTextPane textCurveDefinition = new JTextPane();
    private JEditTextArea textCurveDefinition = new JEditTextArea();
    private JButton buttonCompile;
    private JRadioButton[] buttonCurve;
    
    private ChangeListener sliderChangeListener = new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
            float t = ((float) ((JSlider) e.getSource()).getValue()) / approx;
            desktop.drawParameter(t);
        }
    };
    
    private ActionListener compileActionListener = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            setCurve(new BshCurve(textCurveDefinition.getText()));
        }
    };
    
    private void setCurve(ParametricCurve paraCurve) {
        this.paraCurve = paraCurve;
        desktop.setParametricCurve(paraCurve);
        desktop.repaint();
        prepareSlider();
    }
    
    private ChangeListener expressionChangeListener = new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
            boolean v = ((JRadioButton) e.getSource()).isSelected();
            if (v) {
                textCurveDefinition.setEditable(true);
                textCurveDefinition.setForeground(Color.BLACK);
                buttonCompile.setEnabled(true);
            } else {
                textCurveDefinition.setEditable(false);
                textCurveDefinition.setForeground(Color.LIGHT_GRAY);
                buttonCompile.setEnabled(false);
            }
        }
    };
    
    private ChangeListener curveChangeListener = new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
            JRadioButton src = (JRadioButton) e.getSource();
            if (src.equals(buttonCurve[0])) {
                setCurve(new CircleCurve(150f));
                LineCurve p = new LineCurve(new Point2D.Float(200f, 250f), new Point2D.Float(-100f, -150f));
                p.setParaStart(0);
                p.setParaEnd(1);
                setCurve(p);
            } else if (src.equals(buttonCurve[1])) {
                setCurve(new CircleCurve(150f));
            } else if (src.equals(buttonCurve[2])) {
                setCurve(new OvalCurve(180f, 110f));
            } else if (src.equals(buttonCurve[3])) {
                setCurve(new HyperbolicCurve(10f, 30f));
            } else if (src.equals(buttonCurve[4])) {
                setCurve(new PowerCosCurve());
            } else if (src.equals(buttonCurve[5])) {
                setCurve(new SinCurve());
            } else if (src.equals(buttonCurve[6])) {
                setCurve(new PolynomialCurve());
            }
        }
    };
    
    //Construct the frame
    public MainFrame() {
        
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        
        try {
            InitComponent();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
    //Component initialization
    private void InitComponent() throws Exception {
        
        // create the main desktop
        desktop = new Desktop(paraCurve);
        JPanel desktopPane = new JPanel();
        desktopPane.setLayout(new BorderLayout());
        desktopPane.add(desktop, BorderLayout.CENTER);
        desktopPane.add(slider, BorderLayout.SOUTH);
        
        // create buttons
        JPanel buttonPane = new JPanel();
        JPanel leftPane = new JPanel();
        leftPane.setLayout(new BorderLayout(6, 6));
        buttonPane.setLayout(new GridLayout(0, 1));
        ButtonGroup group = new ButtonGroup();
        buttonCurve = new JRadioButton[7];
        buttonCurve[0] = new JRadioButton("P��mka");
        buttonCurve[0].addChangeListener(curveChangeListener);
        group.add(buttonCurve[0]);
        buttonPane.add(buttonCurve[0]);
        buttonCurve[1] = new JRadioButton("Kru�nice", true);
        buttonCurve[1].addChangeListener(curveChangeListener);
        group.add(buttonCurve[1]);
        buttonPane.add(buttonCurve[1]);
        buttonCurve[2] = new JRadioButton("Elipsa");
        buttonCurve[2].addChangeListener(curveChangeListener);
        group.add(buttonCurve[2]);
        buttonPane.add(buttonCurve[2]);
        buttonCurve[3] = new JRadioButton("Hyperbola");
        buttonCurve[3].addChangeListener(curveChangeListener);
        group.add(buttonCurve[3]);
        buttonPane.add(buttonCurve[3]);
        buttonCurve[4] = new JRadioButton("Mocnina kosinu");
        buttonCurve[4].addChangeListener(curveChangeListener);
        group.add(buttonCurve[4]);
        buttonPane.add(buttonCurve[4]);
        buttonCurve[5] = new JRadioButton("Sinus");
        buttonCurve[5].addChangeListener(curveChangeListener);
        group.add(buttonCurve[5]);
        buttonPane.add(buttonCurve[5]);
        buttonCurve[6] = new JRadioButton("Polynom");
        buttonCurve[6].addChangeListener(curveChangeListener);
        group.add(buttonCurve[6]);
        buttonPane.add(buttonCurve[6]);
        JRadioButton buttonExpression = new JRadioButton("V�raz:");
        buttonExpression.addChangeListener(expressionChangeListener);
        group.add(buttonExpression);
        buttonPane.add(buttonExpression);
        leftPane.add(buttonPane, BorderLayout.NORTH);
        leftPane.add(textCurveDefinition, BorderLayout.CENTER);
        buttonCompile = new JButton("Vykresli");
        buttonCompile.addActionListener(compileActionListener);
        leftPane.add(buttonCompile, BorderLayout.SOUTH);
        
        // create components and butons
        mainPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPane, desktopPane);
        mainPane.setOneTouchExpandable(true);
        mainPane.setDividerLocation(200);
        JPanel contentPane = (JPanel) this.getContentPane();
        contentPane.add(mainPane);
        
        // set the scrollbar up
        slider.addChangeListener(sliderChangeListener);
        prepareSlider();
        
        // set up the frame
        this.setResizable(false);
        this.setSize(new Dimension(800, 600));
        this.setTitle("Geometrie 2 - ZAPLETAL");
        
        // prepare BSH box
        BufferedReader r = new BufferedReader(new FileReader("custom.bsh"));
        StringBuffer sb = new StringBuffer(256);
        while (r.ready()) {
            sb.append(r.readLine() + "\n");
        }
        textCurveDefinition.setText(sb.toString());
        textCurveDefinition.setEditable(false);
        textCurveDefinition.setForeground(Color.LIGHT_GRAY);
        buttonCompile.setEnabled(false);
    }
    
    private void prepareSlider() {
        slider.setValue((int) (paraCurve.getParameterStart() * approx));
        slider.setMinimum((int) (paraCurve.getParameterStart() * approx));
        slider.setMaximum((int) (paraCurve.getParameterEnd() * approx));
    }
    
    //Overridden so we can exit when window is closed
    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            System.exit(0);
        }
    }
}
