package cz.upol.inf01.zapletal.geom2;

import java.awt.geom.Point2D;

/**
 * Author: Luk� Zapletal [lzap@root.cz]
 * Date: 6.6.2003
 */

public class PolynomialCurve extends ParametricCurve {

    // coeficients
    private float A = 2.0f;
    private float B = 1.0f;
    private float C = 2.0f;
    private float D = 8.0f;
    private float E = 4.0f;

    public PolynomialCurve(float a, float b, float c, float d, float e) {
        A = a;
        B = b;
        C = c;
        D = d;
        E = e;
    }

    public PolynomialCurve() {
    }

    /**
     * Implementation for this object.
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve
     */
    public Point2D.Float getValue(float t) {
        return new Point2D.Float(
                t,
                (float) ((-A / B) * Math.pow(t, 3) - (C / B) * t*t - (D / B) * t - (E / B)));
    }

    /**
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve#getParameterEnd()
     */
    public float getParameterEnd() {
        return 3f;
    }

    /**
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve#getParameterStart()
     */
    public float getParameterStart() {
        return -3f;
    }
}
