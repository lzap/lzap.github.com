package cz.upol.inf01.zapletal.geom2;

import java.awt.geom.Point2D;
import bsh.Interpreter;

/**
 * BeanShell runtime interpreted curve.
 * 
 * @author Luk� Zapletal
 */
public class BshCurve extends ParametricCurve {
	
	private Interpreter inter;
	private ParametricFunction function;
	
	public BshCurve(String implementation) {
		
		// prepare the beanshell
		inter = new Interpreter();
		
		// eval the body
		try
		{
			inter.eval(implementation);
			function = (ParametricFunction) inter.eval("return (ParametricFunction)this");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public float getParameterStart() {
		try
		{
			return ((Float) inter.get("parameterStart")).floatValue();
		}
		catch(Exception e)
		{
			return -PARAMETER_INFINITY;
		}
	}
	
	public float getParameterEnd() {
		try
		{
			return ((Float) inter.get("parameterEnd")).floatValue();
		}
		catch(Exception e)
		{
			return PARAMETER_INFINITY;
		}
	}
	
	/**
	 * Implementation for this object.
     * Calls beanshell function.
	 * @see cz.upol.inf01.zapletal.geom2.ParametricCurve
	 */
	public Point2D.Float getValue(float t) {
        try {
		    return function.getValue(t);
        } catch (Exception e) {
            return new Point2D.Float(0, 0);
        }
	}
	
}
