package cz.upol.inf01.zapletal.geom2;

import javax.vecmath.Vector2f;
import java.awt.geom.Point2D;

/**
 * Line curve. ;-)
 *
 * @author Luk� Zapletal
 */
public class LineCurve extends ParametricCurve {
    
    private Vector2f vector;
    private Point2D.Float position;
    private float paraStart = 0;
    private float paraEnd = PARAMETER_INFINITY;
    
    public LineCurve(Point2D.Float vector, Point2D.Float position) {
        this.vector = new Vector2f(vector.x, vector.y);
        this.position = position;
    }
    
    public LineCurve(Vector2f vector, Point2D.Float position) {
        this.vector = vector;
        this.position = position;
    }
    
    /**
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve#getParameterStart()
     */
    public float getParameterStart() {
        return paraStart;
    }
    
    /**
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve#getParameterEnd()
     */
    public float getParameterEnd() {
        return paraEnd;
    }
    
    /**
     * Implementation for this object.
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve
     */
    public Point2D.Float getValue(float t) {
        return new Point2D.Float(
        position.x + t * vector.x,
        position.y + t * vector.y);
    }
    
    public void setParaStart(float paraStart) {
        this.paraStart = paraStart;
    }
    
    public void setParaEnd(float paraEnd) {
        this.paraEnd = paraEnd;
    }
    
}
