package cz.upol.inf01.zapletal.geom2;

import java.awt.geom.Point2D;

/**
 * Oval curve (ellipse).
 * Author: Luk� Zapletal [lzap@root.cz]
 * Date: 1.5.2003
 */
public class HyperbolicCurve extends ParametricCurve {

    /** Position of centre */
    protected Point2D.Float c;
    /** Radius */
    protected float a;
    protected float b;

    public HyperbolicCurve(float a, float b, Point2D.Float c) {
        this.c = c;
        this.a = a;
        this.b = b;
    }

    public HyperbolicCurve(float a, float b) {
        this(a, b, new Point2D.Float(0, 0));
    }

    public HyperbolicCurve() {
        this(100, 160);
    }

    public static float sinh(float x) {
        return (float) ((Math.pow(Math.E, x) - Math.pow(Math.E, -x)) / 2d);
    }

    public static float cosh(float x) {
        return (float) ((Math.pow(Math.E, x) + Math.pow(Math.E, -x)) / 2d);
    }

    /**
     * Implementation for this object.
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve
     */
    public Point2D.Float getValue(float t) {
        return new Point2D.Float(
            c.x + a * cosh(t),
            c.y + b * sinh(t));
    }

    /**
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve#getParameterEnd()
     */
    public float getParameterEnd() {
        return 3f;
    }

    /**
     * @see cz.upol.inf01.zapletal.geom2.ParametricCurve#getParameterStart()
     */
    public float getParameterStart() {
        return -3f;
    }
}
