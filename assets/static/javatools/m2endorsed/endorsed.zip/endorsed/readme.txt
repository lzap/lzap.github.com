Tento ZIP soubor je v MAVEN_OPTS nastaven jako prvni na BOOTCLASSPATH. Je mozne 
do nej zkopirovat obsahy JAR souboru, ktere maji pretizit systemovy RT.JAR.

Napriklad pro pouziti novejsich webovych sluzeb je treba do BOOTCLASSPATH dat 
na zacatek knihovny jaxb-api.jar a jaxws-api.jar. Pro tyto ucely se hodi prave 
tento ALL.ZIP.

Pro korektni pouziti je nutne nastavit systemovou promennou pro Maven2 takto:

set MAVEN_OPTS=-Xbootclasspath/p:%M2_HOME%\endorsed\all.zip

Musite mit nastavenou korektne promennou M2_HOME!
